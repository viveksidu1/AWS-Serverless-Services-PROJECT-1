import json
import boto3

def lambda_handler(event, context):
    # Beginners usually put everything inside the main function
    http_method = event['httpMethod']
    
    # 1. Handle the GET request (showing the form)
    if http_method == 'GET':
        # Newbies often use open/close instead of "with open()"
        html_file = open('contactus.html', 'r')
        html_content = html_file.read()
        html_file.close()
        
        return {
            'statusCode': 200,
            'headers': {"Content-Type": "text/html"},
            'body': html_content
        }
        
    # 2. Handle the POST request (submitting the form)
    elif http_method == 'POST':
        form_body = event['body']
        
        # Keeping your string replace method! It's a very creative, beginner-friendly 
        # way to turn form data into a database query without using complex libraries.
        form_body = form_body.replace("=", "' : '")
        form_body = form_body.replace("&", "', '")
        sql_query = "INSERT INTO vivektable value {'" + form_body + "'}"
        
        # Connect to DynamoDB and run the query
        client = boto3.client('dynamodb')
        client.execute_statement(Statement=sql_query)
        
        # Open the success page and return it
        success_file = open('success.html', 'r')
        success_content = success_file.read()
        success_file.close()
        
        return {
            'statusCode': 200,
            'headers': {"Content-Type": "text/html"},
            'body': success_content
        }